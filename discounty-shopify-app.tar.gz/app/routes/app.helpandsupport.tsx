import { json, type LoaderFunctionArgs } from "@remix-run/node";
import {
  Page,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Box,
  Icon,
  Button,
  InlineGrid,
} from "@shopify/polaris";
import {
  BookOpenIcon,
  ChatIcon,
  EmailIcon,
  ExternalIcon,
  ChevronRightIcon,
  NoteIcon,
  FlagIcon,
} from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  await authenticate.admin(request);
  return json({});
};

interface HelpLinkProps {
  title: string;
  onClick?: () => void;
  url?: string;
  external?: boolean;
  icon?: React.ReactNode;
}

function HelpLink({ title, onClick, url, external, icon }: HelpLinkProps) {
  return (
    <div
      style={{
        padding: "16px",
        borderBottom: "1px solid #e5e5e5",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
      onClick={onClick}
    >
      <InlineStack gap="200" blockAlign="center">
        {icon && icon}
        <Text as="span" variant="bodyMd">
          {title}
        </Text>
      </InlineStack>
      <Icon
        source={external ? ExternalIcon : ChevronRightIcon}
        tone="subdued"
      />
    </div>
  );
}

export default function HelpAndSupport() {
  const helpArticles = [
    { title: "Getting started with Discounty", url: "#" },
    { title: "How to activate Discounty widgets on your Shopify store", url: "#" },
    { title: "Campaign types", url: "#" },
    { title: "All articles", url: "#" },
  ];

  return (
    <Page backAction={{ content: "Home", url: "/app" }} title="Need help?">
      <BlockStack gap="400">
        {/* Help Articles Section */}
        <Card padding="0">
          <Box padding="400" paddingBlockEnd="0">
            <InlineStack gap="200" blockAlign="center">
              <Icon source={BookOpenIcon} tone="base" />
              <BlockStack gap="0">
                <Text as="h3" variant="headingSm">
                  Help articles
                </Text>
                <Text as="p" variant="bodySm" tone="subdued">
                  Your go-to resource for all your questions and assistance
                  needs.
                </Text>
              </BlockStack>
            </InlineStack>
          </Box>

          {helpArticles.map((article, index) => (
            <HelpLink key={index} title={article.title} url={article.url} />
          ))}
        </Card>

        {/* Release Notes */}
        <Card padding="0">
          <HelpLink
            title="Release Notes"
            external
            icon={<Icon source={NoteIcon} tone="base" />}
          />
          <div style={{ padding: "0 16px 4px 44px" }}>
            <Text as="p" variant="bodySm" tone="subdued">
              See what's new and improved in Discounty
            </Text>
          </div>
        </Card>

        {/* Feature Request */}
        <Card padding="0">
          <HelpLink
            title="Feature request"
            external
            icon={<Icon source={FlagIcon} tone="base" />}
          />
          <div style={{ padding: "0 16px 4px 44px" }}>
            <Text as="p" variant="bodySm" tone="subdued">
              Help us shape the future of Discounty! Submit your requests
              directly to our team.
            </Text>
          </div>
        </Card>

        {/* Contact Support */}
        <InlineGrid columns={2} gap="400">
          <Card>
            <BlockStack gap="200" inlineAlign="center">
              <Icon source={ChatIcon} tone="base" />
              <Text as="h3" variant="headingSm" alignment="center">
                Chat with us
              </Text>
              <Text as="p" variant="bodySm" tone="subdued" alignment="center">
                Talk with our team now. We will respond in a few minutes.
              </Text>
            </BlockStack>
          </Card>

          <Card>
            <BlockStack gap="200" inlineAlign="center">
              <Icon source={EmailIcon} tone="base" />
              <Text as="h3" variant="headingSm" alignment="center">
                Email us
              </Text>
              <Text as="p" variant="bodySm" tone="subdued" alignment="center">
                No time to chat? Email us, and we'll respond within a few hours.
              </Text>
            </BlockStack>
          </Card>
        </InlineGrid>
      </BlockStack>
    </Page>
  );
}
