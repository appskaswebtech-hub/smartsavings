import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, useNavigate, useSearchParams } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Button,
  Box,
  Tabs,
  EmptyState,
  ProgressBar,
  IndexFilters,
  useSetIndexFiltersMode,
  IndexTable,
  Badge,
  Thumbnail,
} from "@shopify/polaris";
import { useState, useCallback } from "react";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);

  // TODO: Fetch campaigns from database
  return json({
    campaigns: [],
    plan: {
      name: "Starter",
      activeVariants: 0,
      maxVariants: 10,
      createdCampaigns: 0,
      maxCampaigns: 3,
    },
  });
};

export default function Campaigns() {
  const { campaigns, plan } = useLoaderData<typeof loader>();
  const navigate = useNavigate();
  const [selectedTab, setSelectedTab] = useState(0);

  const tabs = [
    { id: "all", content: "All", accessibilityLabel: "All campaigns" },
    { id: "active", content: "Active", accessibilityLabel: "Active campaigns" },
    {
      id: "scheduled",
      content: "Scheduled",
      accessibilityLabel: "Scheduled campaigns",
    },
    {
      id: "expired",
      content: "Expired",
      accessibilityLabel: "Expired campaigns",
    },
  ];

  const handleTabChange = useCallback(
    (selectedTabIndex: number) => setSelectedTab(selectedTabIndex),
    []
  );

  return (
    <Page
      backAction={{ content: "Home", url: "/app" }}
      title="Campaigns"
      primaryAction={{
        content: "Create campaign",
        onAction: () => {
          // TODO: Navigate to campaign creation
        },
      }}
    >
      <BlockStack gap="600">
        {/* Plan Overview */}
        <Card>
          <InlineStack align="space-between" blockAlign="center">
            <BlockStack gap="100">
              <Text as="span" variant="bodySm" tone="subdued">
                Current plan:
              </Text>
              <Text as="span" variant="headingSm" fontWeight="bold">
                {plan.name}
              </Text>
            </BlockStack>

            <InlineStack gap="200" blockAlign="center">
              <Box width="200px">
                <ProgressBar
                  progress={(plan.activeVariants / plan.maxVariants) * 100}
                  size="small"
                  tone="primary"
                />
              </Box>
              <BlockStack gap="0">
                <Text as="span" variant="bodySm" tone="subdued">
                  Active discounted variants
                </Text>
                <Text as="span" variant="headingSm" fontWeight="bold">
                  {plan.activeVariants}/{plan.maxVariants}
                </Text>
              </BlockStack>
            </InlineStack>

            <InlineStack gap="200" blockAlign="center">
              <Box width="200px">
                <ProgressBar
                  progress={(plan.createdCampaigns / plan.maxCampaigns) * 100}
                  size="small"
                  tone="primary"
                />
              </Box>
              <BlockStack gap="0">
                <Text as="span" variant="bodySm" tone="subdued">
                  Created campaigns
                </Text>
                <Text as="span" variant="headingSm" fontWeight="bold">
                  {plan.createdCampaigns}/{plan.maxCampaigns}
                </Text>
              </BlockStack>
            </InlineStack>
          </InlineStack>
        </Card>

        {/* Campaign List */}
        <Card padding="0">
          <Tabs tabs={tabs} selected={selectedTab} onSelect={handleTabChange}>
            <Box padding="400">
              {campaigns.length === 0 ? (
                <EmptyState
                  heading="Create a discount campaign"
                  image=""
                >
                  <p>
                    Create campaigns to apply discounts to your products
                    automatically
                  </p>
                  <Box paddingBlockStart="400">
                    <Button variant="primary">Create campaign</Button>
                  </Box>
                </EmptyState>
              ) : (
                <IndexTable
                  itemCount={campaigns.length}
                  headings={[
                    { title: "Campaign" },
                    { title: "Type" },
                    { title: "Status" },
                    { title: "Discounted variants" },
                    { title: "Start date" },
                    { title: "End date" },
                  ]}
                  selectable={false}
                >
                  {campaigns.map((campaign: any, index: number) => (
                    <IndexTable.Row
                      id={campaign.id}
                      key={campaign.id}
                      position={index}
                    >
                      <IndexTable.Cell>
                        <Text as="span" variant="bodyMd" fontWeight="bold">
                          {campaign.name}
                        </Text>
                      </IndexTable.Cell>
                      <IndexTable.Cell>{campaign.type}</IndexTable.Cell>
                      <IndexTable.Cell>
                        <Badge
                          tone={
                            campaign.status === "active"
                              ? "success"
                              : campaign.status === "scheduled"
                              ? "info"
                              : undefined
                          }
                        >
                          {campaign.status}
                        </Badge>
                      </IndexTable.Cell>
                      <IndexTable.Cell>
                        {campaign.discountedVariants}
                      </IndexTable.Cell>
                      <IndexTable.Cell>{campaign.startDate}</IndexTable.Cell>
                      <IndexTable.Cell>{campaign.endDate}</IndexTable.Cell>
                    </IndexTable.Row>
                  ))}
                </IndexTable>
              )}
            </Box>
          </Tabs>
        </Card>
      </BlockStack>
    </Page>
  );
}
