import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, useSubmit } from "@remix-run/react";
import {
  Page,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Button,
  Box,
  InlineGrid,
  Badge,
  Divider,
  Icon,
  List,
} from "@shopify/polaris";
import { CheckIcon } from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  await authenticate.admin(request);

  return json({
    currentPlan: "starter",
    plans: [
      {
        id: "starter",
        name: "Starter",
        price: "Free",
        priceNote: "Free forever",
        features: [
          "Up to 10 discounted variants",
          "Up to 3 campaigns",
          "Quantity discount",
          "Bulk price editor",
          "Customizable widgets",
          "Chat & email support",
        ],
      },
      {
        id: "essential",
        name: "Essential",
        price: "$12.99",
        priceNote: "/month",
        features: [
          "Up to 100 discounted variants",
          "Up to 10 campaigns",
          "All discount types",
          "Bulk price editor",
          "Customizable widgets",
          "Campaign scheduling",
          "Priority support",
        ],
        popular: true,
      },
      {
        id: "professional",
        name: "Professional",
        price: "$24.99",
        priceNote: "/month",
        features: [
          "Up to 1,000 discounted variants",
          "Unlimited campaigns",
          "All discount types",
          "Advanced analytics",
          "Bulk price editor",
          "Customizable widgets",
          "Campaign scheduling",
          "Dedicated support",
        ],
      },
      {
        id: "ultimate",
        name: "Ultimate",
        price: "$49.99",
        priceNote: "/month",
        features: [
          "Unlimited discounted variants",
          "Unlimited campaigns",
          "All discount types",
          "Advanced analytics",
          "Bulk price editor",
          "Customizable widgets",
          "Campaign scheduling",
          "AI campaign assistant",
          "White-glove onboarding",
          "Dedicated account manager",
        ],
      },
    ],
  });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const formData = await request.formData();
  const planId = formData.get("planId") as string;

  // TODO: Handle plan upgrade/downgrade via Shopify billing API
  return json({ success: true });
};

export default function Plans() {
  const { currentPlan, plans } = useLoaderData<typeof loader>();
  const submit = useSubmit();

  const handleSelectPlan = (planId: string) => {
    submit({ planId }, { method: "post" });
  };

  return (
    <Page backAction={{ content: "Home", url: "/app" }} title="Plans">
      <BlockStack gap="400">
        <Text as="p" variant="bodyMd" tone="subdued">
          Choose the plan that best fits your business needs.
        </Text>

        <InlineGrid columns={4} gap="400">
          {plans.map((plan) => (
            <Card key={plan.id}>
              <BlockStack gap="400">
                <BlockStack gap="200">
                  <InlineStack gap="200" blockAlign="center">
                    <Text as="h3" variant="headingMd">
                      {plan.name}
                    </Text>
                    {plan.popular && <Badge tone="success">Popular</Badge>}
                  </InlineStack>

                  <InlineStack gap="100" blockAlign="end">
                    <Text as="span" variant="headingXl">
                      {plan.price}
                    </Text>
                    <Text as="span" variant="bodySm" tone="subdued">
                      {plan.priceNote}
                    </Text>
                  </InlineStack>
                </BlockStack>

                <Divider />

                <BlockStack gap="200">
                  {plan.features.map((feature, index) => (
                    <InlineStack key={index} gap="200" blockAlign="start">
                      <Box>
                        <Icon source={CheckIcon} tone="success" />
                      </Box>
                      <Text as="span" variant="bodySm">
                        {feature}
                      </Text>
                    </InlineStack>
                  ))}
                </BlockStack>

                <Box paddingBlockStart="200">
                  {currentPlan === plan.id ? (
                    <Button disabled fullWidth>
                      Current plan
                    </Button>
                  ) : (
                    <Button
                      variant={plan.popular ? "primary" : undefined}
                      fullWidth
                      onClick={() => handleSelectPlan(plan.id)}
                    >
                      {plan.price === "Free" ? "Downgrade" : "Upgrade"}
                    </Button>
                  )}
                </Box>
              </BlockStack>
            </Card>
          ))}
        </InlineGrid>
      </BlockStack>
    </Page>
  );
}
