import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData, useNavigate } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Button,
  Box,
  InlineGrid,
  Tabs,
  Badge,
  Tooltip,
  Icon,
} from "@shopify/polaris";
import { InfoIcon } from "@shopify/polaris-icons";
import { useState, useCallback } from "react";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  await authenticate.admin(request);
  return json({});
};

interface WidgetCardProps {
  title: string;
  description: string;
  tags: string[];
  previewContent: React.ReactNode;
  styleOptions?: { colors: string[] };
}

function WidgetCard({
  title,
  description,
  tags,
  previewContent,
  styleOptions,
}: WidgetCardProps) {
  return (
    <Card>
      <BlockStack gap="400">
        {/* Preview Area */}
        <Box
          background="bg-surface-secondary"
          borderRadius="200"
          padding="400"
          minHeight="140px"
        >
          <BlockStack gap="200">
            {styleOptions && (
              <InlineStack gap="200" blockAlign="center">
                <Text as="span" variant="bodySm" tone="subdued">
                  Style:
                </Text>
                {styleOptions.colors.map((color, i) => (
                  <div
                    key={i}
                    style={{
                      width: "20px",
                      height: "20px",
                      borderRadius: "4px",
                      background: color,
                      border: "1px solid #ddd",
                      cursor: "pointer",
                    }}
                  />
                ))}
              </InlineStack>
            )}
            <Box>{previewContent}</Box>
          </BlockStack>
        </Box>

        {/* Info */}
        <InlineStack align="space-between" blockAlign="start">
          <BlockStack gap="100">
            <Text as="h3" variant="headingSm">
              {title}
            </Text>
            <Text as="p" variant="bodySm" tone="subdued">
              {description}
            </Text>
          </BlockStack>
          <Tooltip content="More info">
            <Icon source={InfoIcon} tone="subdued" />
          </Tooltip>
        </InlineStack>

        {/* Tags */}
        <InlineStack gap="200">
          {tags.map((tag, index) => (
            <Badge key={index} tone="info">
              {tag}
            </Badge>
          ))}
        </InlineStack>
      </BlockStack>
    </Card>
  );
}

export default function Customization() {
  const [selectedTab, setSelectedTab] = useState(0);

  const tabs = [
    { id: "all", content: "All" },
    { id: "bulk-price", content: "Bulk price editor" },
    { id: "quantity-discount", content: "Quantity discount" },
    { id: "cart-goal", content: "Cart goal" },
    { id: "buy-x-get-y", content: "Buy X get Y" },
    { id: "shipping-discount", content: "Shipping discount" },
  ];

  const handleTabChange = useCallback(
    (selectedTabIndex: number) => setSelectedTab(selectedTabIndex),
    []
  );

  // Countdown timer preview
  const CountdownPreview = ({ label, color }: { label: string; color: string }) => (
    <div style={{ padding: "8px 0" }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          padding: "8px 12px",
          background: "white",
          borderRadius: "8px",
          border: "1px solid #e5e5e5",
        }}
      >
        <span style={{ fontSize: "12px" }}>🔥 {label} :</span>
        <div style={{ display: "flex", gap: "4px" }}>
          {["03", "12", "25", "07"].map((num, i) => (
            <div
              key={i}
              style={{
                background: color,
                color: "white",
                padding: "4px 6px",
                borderRadius: "4px",
                fontSize: "12px",
                fontWeight: "bold",
                minWidth: "24px",
                textAlign: "center" as const,
              }}
            >
              {num}
            </div>
          ))}
        </div>
      </div>
      <div
        style={{
          display: "flex",
          gap: "4px",
          marginTop: "4px",
          paddingLeft: "100px",
        }}
      >
        {["Day", "Hrs", "Mins", "Secs"].map((unit) => (
          <span
            key={unit}
            style={{
              fontSize: "9px",
              color: "#999",
              minWidth: "24px",
              textAlign: "center" as const,
              display: "inline-block",
            }}
          >
            {unit}
          </span>
        ))}
      </div>
    </div>
  );

  // Quantity/Value table preview
  const QuantityTablePreview = () => (
    <div
      style={{
        background: "white",
        borderRadius: "8px",
        border: "1px solid #e5e5e5",
        padding: "8px",
        fontSize: "11px",
      }}
    >
      <div style={{ fontWeight: "bold", marginBottom: "4px", color: "#333" }}>
        Buy more, Save more!
      </div>
      <table style={{ width: "100%", borderCollapse: "collapse" as const }}>
        <thead>
          <tr style={{ borderBottom: "1px solid #eee" }}>
            <th style={{ textAlign: "left" as const, padding: "3px", color: "#666" }}>Qty</th>
            <th style={{ textAlign: "left" as const, padding: "3px", color: "#666" }}>Discount</th>
          </tr>
        </thead>
        <tbody>
          {[
            { qty: "2+", discount: "5%" },
            { qty: "4+", discount: "10%" },
            { qty: "8+", discount: "15%" },
          ].map((row, i) => (
            <tr key={i} style={{ borderBottom: "1px solid #f5f5f5" }}>
              <td style={{ padding: "3px" }}>{row.qty}</td>
              <td style={{ padding: "3px" }}>{row.discount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  // Buy X Get Y popup preview
  const BuyXGetYPreview = () => (
    <div
      style={{
        background: "white",
        borderRadius: "8px",
        border: "1px solid #e5e5e5",
        padding: "8px",
        fontSize: "11px",
      }}
    >
      <div style={{ fontWeight: "bold", color: "#333", marginBottom: "4px" }}>
        You can get points in these products
      </div>
      <div style={{ display: "flex", gap: "8px" }}>
        <div
          style={{
            width: "40px",
            height: "40px",
            background: "#f0f0f0",
            borderRadius: "4px",
          }}
        />
        <div>
          <div style={{ fontSize: "10px", color: "#666" }}>Oats powder</div>
          <div style={{ fontSize: "10px", fontWeight: "bold" }}>
            Discount badge: <span style={{ color: "#e53e3e" }}>Discount</span>
          </div>
        </div>
      </div>
    </div>
  );

  // Shipping progress bar preview
  const ShippingProgressPreview = () => (
    <div
      style={{
        background: "white",
        borderRadius: "8px",
        border: "1px solid #e5e5e5",
        padding: "12px",
      }}
    >
      <div
        style={{
          fontWeight: "bold",
          fontSize: "13px",
          marginBottom: "8px",
        }}
      >
        You're $25 away from free shipping
      </div>
      <div
        style={{
          background: "#e5e5e5",
          borderRadius: "10px",
          height: "8px",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            background: "linear-gradient(90deg, #10b981, #34d399)",
            width: "60%",
            height: "100%",
            borderRadius: "10px",
          }}
        />
      </div>
      <div
        style={{
          fontSize: "10px",
          color: "#999",
          marginTop: "4px",
        }}
      >
        Message: You're $25 away!
      </div>
    </div>
  );

  // Saving on cart preview
  const SavingOnCartPreview = () => (
    <div
      style={{
        background: "white",
        borderRadius: "8px",
        border: "1px solid #e5e5e5",
        padding: "8px",
        fontSize: "12px",
      }}
    >
      <table style={{ width: "100%" }}>
        <tbody>
          <tr>
            <td style={{ color: "#666" }}>Subtotal</td>
            <td style={{ textAlign: "right" as const }}>$110</td>
          </tr>
          <tr>
            <td>
              <span
                style={{
                  background: "#fee2e2",
                  color: "#e53e3e",
                  padding: "1px 6px",
                  borderRadius: "3px",
                  fontSize: "11px",
                }}
              >
                Saving
              </span>
            </td>
            <td
              style={{
                textAlign: "right" as const,
                color: "#e53e3e",
              }}
            >
              $10
            </td>
          </tr>
          <tr style={{ fontWeight: "bold" }}>
            <td>Total</td>
            <td style={{ textAlign: "right" as const }}>$90</td>
          </tr>
        </tbody>
      </table>
    </div>
  );

  // Floating button preview
  const FloatingButtonPreview = () => (
    <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
      <div
        style={{
          width: "44px",
          height: "44px",
          borderRadius: "12px",
          background: "#10b981",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          fontSize: "20px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
        }}
      >
        🎁
      </div>
      <div
        style={{
          background: "white",
          borderRadius: "8px",
          border: "1px solid #e5e5e5",
          padding: "8px",
          fontSize: "11px",
        }}
      >
        <div style={{ display: "flex", gap: "4px", alignItems: "center" }}>
          <span>Mobile:</span>
          <div
            style={{
              width: "16px",
              height: "16px",
              background: "#10b981",
              borderRadius: "3px",
            }}
          />
          <div
            style={{
              width: "16px",
              height: "16px",
              background: "#1e3a5f",
              borderRadius: "3px",
            }}
          />
        </div>
      </div>
    </div>
  );

  return (
    <Page backAction={{ content: "Home", url: "/app" }} title="Customization">
      <BlockStack gap="200">
        <Text as="p" variant="bodyMd" tone="subdued">
          Choose a widget to customize its appearance or content.
        </Text>

        <Tabs tabs={tabs} selected={selectedTab} onSelect={handleTabChange}>
          <Box paddingBlockStart="400">
            <InlineGrid columns={3} gap="400">
              {/* Starts in countdown timer */}
              <WidgetCard
                title="Starts in countdown timer"
                description="Set new style for starts in countdown timer."
                tags={["All types"]}
                styleOptions={{ colors: ["#10b981", "#1e3a5f"] }}
                previewContent={
                  <CountdownPreview label="Sale starts in" color="#e53e3e" />
                }
              />

              {/* Ends in countdown timer */}
              <WidgetCard
                title="Ends in countdown timer"
                description="Set new style for ends in countdown timer."
                tags={["All types"]}
                styleOptions={{ colors: ["#10b981", "#1e3a5f"] }}
                previewContent={
                  <CountdownPreview label="Sale ends in" color="#059669" />
                }
              />

              {/* Quantity/Value table */}
              <WidgetCard
                title="Quantity/Value table"
                description="Change content and style of the tier table."
                tags={["Quantity discount", "Cart goal"]}
                previewContent={<QuantityTablePreview />}
              />

              {/* Buy X get Y pop-up */}
              <WidgetCard
                title="Buy X get Y pop-up"
                description="Change pop-up text, color and behaviour."
                tags={["Buy X get Y"]}
                previewContent={<BuyXGetYPreview />}
              />

              {/* Shipping progress bar */}
              <WidgetCard
                title="Shipping progress bar"
                description="Change content and style of the progress bar."
                tags={["Shipping discount"]}
                styleOptions={{ colors: ["#10b981", "#1e3a5f"] }}
                previewContent={<ShippingProgressPreview />}
              />

              {/* Saving on cart */}
              <WidgetCard
                title="Saving on cart"
                description='Customize "Saving & Total" widget on cart.'
                tags={["All types"]}
                previewContent={<SavingOnCartPreview />}
              />

              {/* Buy X get Y Floating button */}
              <WidgetCard
                title="Buy X get Y Floating button"
                description="Customize FAB style shown after closing pop-up."
                tags={["Buy X get Y"]}
                previewContent={<FloatingButtonPreview />}
              />
            </InlineGrid>
          </Box>
        </Tabs>
      </BlockStack>
    </Page>
  );
}
